import "ol/ol.css";
import * as olProj from "ol/proj";
import Feature from "ol/Feature";
import Map from "ol/Map";
import { unByKey } from "ol/Observable";
import View from "ol/View";
import { easeOut } from "ol/easing";
import Point from "ol/geom/Point";
import { Tile as TileLayer, Vector as VectorLayer } from "ol/layer";
import { fromLonLat } from "ol/proj";
import { OSM, Vector as VectorSource } from "ol/source";
import { Circle as CircleStyle, Stroke, Style } from "ol/style";
import { getVectorContext } from "ol/render";

var tileLayer = new TileLayer({
  source: new OSM({
    wrapX: false
  })
});

var map = new Map({
  layers: [tileLayer],
  target: "map",
  view: new View({
    center: olProj.fromLonLat([87.309032, 22.315826]),
    zoom: 17.88,
    multiWorld: true
  })
});

var source = new VectorSource({
  wrapX: false
});
var vector = new VectorLayer({
  source: source
});
map.addLayer(vector);

function addRandomFeature() {
  var x = Math.random(3) / 1000 + 87.309032;
  var y = Math.random(3) / 1000 + 22.315826;
  document.getElementById("output").innerHTML =
    document.getElementById("output").innerHTML +
    "<br>" +
    "Point found at x= " +
    x +
    " y= " +
    y;
  var geom = new Point(fromLonLat([x, y]));
  var feature = new Feature(geom);
  source.addFeature(feature);
}

var duration = 3000;
function flash(feature) {
  var start = new Date().getTime();
  var listenerKey = tileLayer.on("postrender", animate);

  function animate(event) {
    var vectorContext = getVectorContext(event);
    var frameState = event.frameState;
    var flashGeom = feature.getGeometry().clone();
    var elapsed = frameState.time - start;
    var elapsedRatio = elapsed / duration;
    // radius will be 5 at start and 30 at end.
    var radius = easeOut(elapsedRatio) * 25 + 5;
    var opacity = easeOut(1 - elapsedRatio);

    var style = new Style({
      image: new CircleStyle({
        radius: radius,
        stroke: new Stroke({
          color: "rgba(255, 0, 0, " + opacity + ")",
          width: 0.25 + opacity
        })
      })
    });

    vectorContext.setStyle(style);
    vectorContext.drawGeometry(flashGeom);
    if (elapsed > duration) {
      unByKey(listenerKey);
      return;
    }
    // tell OpenLayers to continue postrender animation
    map.render();
  }
}

source.on("addfeature", function(e) {
  flash(e.feature);
});

window.setInterval(addRandomFeature, 2000);
